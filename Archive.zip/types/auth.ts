export type SocialLoginD = 'google' | 'twitter' | 'github';
