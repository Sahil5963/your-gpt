export const THEME = {
  navbarHeight: 60,
  appNavbarHeight: 60,
};
