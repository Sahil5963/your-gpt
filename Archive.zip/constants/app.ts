export const STORAGE_KEYS = {
  token: 'token',
};
