import React from 'react';

export default function ProjectManagePage(p) {
  return (
    <div>{/* <ManageProject projectId={10} onUpdate={() => {}} /> */}</div>
  );
}
