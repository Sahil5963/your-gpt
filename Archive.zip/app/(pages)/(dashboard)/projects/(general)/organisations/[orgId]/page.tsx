import React from 'react';

export default function EditOrganisation() {
  return <div></div>;
}
