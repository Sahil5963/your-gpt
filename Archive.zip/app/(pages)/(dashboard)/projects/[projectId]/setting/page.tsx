import React from 'react';

export default function AppSetting() {
  return <div>APP SETTINGS</div>;
}
