import FaqPlugin from 'app/components/plugins/Faq';
import React from 'react';

export default function FaqP() {
  return (
    <div>
      <FaqPlugin />
    </div>
  );
}
